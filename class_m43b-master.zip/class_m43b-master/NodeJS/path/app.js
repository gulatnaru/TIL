const path = require('path');

const pathObj = path.parse(__filename);
console.log(pathObj);