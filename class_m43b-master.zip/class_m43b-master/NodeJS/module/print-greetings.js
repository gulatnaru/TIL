const greetings = require('./greetings');

console.log(
  `Korean: ${greetings.sayHelloInKorean()}
  & English: ${greetings.sayHelloInEnglish()}
  & Swedish: ${greetings.sayHelloInSwedish()}`
);