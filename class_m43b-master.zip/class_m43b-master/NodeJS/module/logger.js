const url = 'http://hphk.kr';

const log = (msg) => {
  // Looooooooooooogic
  console.log(`Logging message: ${msg}`);
};

module.exports = log;
