
module.exports = {
  sayHelloInKorean(){
    return '안녕'
  },

  sayHelloInEnglish() {
    return 'Hello'
  },

  sayHelloInSwedish() {
    return 'Hej'
  },
};

// module.exports = Car

// class Car {
//   constructor(name){
//     this.name = name
//   }

//   drive(){
//     return 'Vrooom';
//   }
// }