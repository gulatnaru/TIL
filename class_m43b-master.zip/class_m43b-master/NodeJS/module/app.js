const logger = require('./logger');

logger("GET '/' 127.0.0.1");


