/* process */
// 시스템 환경
// console.log(process.env);

// arguments
// console.log(process.argv);

// 프로그램 종료
// process.exit(0);

// process.exit(1);