[].forEach();

[].map();

[].filter();

[].find();

[].every();

[].some();

[].reduce();
