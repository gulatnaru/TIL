const name = 'Yu Tae Young'
const string = 'My name is ' + name;

const newString = `My name is ${name}`

const time = `The year is ${new Date().getFullYear()}`