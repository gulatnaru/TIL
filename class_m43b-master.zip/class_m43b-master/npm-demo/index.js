const mc = require('multicampus');

console.log(mc.hphk());
console.log(mc.getName());
console.log(mc.cheer());
