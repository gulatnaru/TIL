module.exports = {
  hphk(){
    return "Happy Hacking with hphk";
  },

  getName(){
    return "neo";
  },

  cheer(){
    return "٩(ᐛ)و";
  }
}